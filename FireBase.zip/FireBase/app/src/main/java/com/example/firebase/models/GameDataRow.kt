package com.example.firebase.models

data class GameDataRow(val name: String, val genre: String, val releaseYear: Int) {
}