package com.example.firebase.models

import android.view.View
import android.widget.TextView
import com.example.firebase.R

class Adapter(private val gameArray: ArrayList<GameDataRow>):
    RecyclerView.Adapter<Adapter.MyViewHolder> {
    class MyViewHolder(view: View): RecyclerView.ViewHolder(view) {
        val gameName = view.findViewById<TextView>(R.id.NAZWA)
        val gameGenre = view.findViewById<TextView>(R.id.GENRE)
        val gameYear = view.findViewById<TextView>(R.id.YEAR)
    }
}